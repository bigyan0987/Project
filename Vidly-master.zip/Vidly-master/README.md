# Vidly
Udemy - The Complete ASP.NET MVC 5 Course

Doing the proposed exercises from the following course: https://www.udemy.com/the-complete-aspnet-mvc-5-course/
